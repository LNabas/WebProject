<!DOCTYPE html>
<html lang="en">
<head>

    <title>BDE EXIA Lyon</title>
    <?php require_once 'inc/head.php'; ?>
    <link rel="stylesheet" type="text/css" href="css/style.css">


</head>

<body>
<?php require_once 'inc/header.php'; ?>

<div class="jumbotron jumbotron-sm">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <h1 class="h1">
                    Contact us <small>student or Organism</small></h1>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <strong>Thanks to contact us, we will ansker quickly</strong>
    <form>
        <legend><span class="glyphicon glyphicon-globe"></span>Our adress</legend>
        <address>
            <strong>BDE CESI Ecully.</strong><br>
            19 avenue Guy de Collongue <br>
            Ecully, 69130<br>

        </address>

    </form>
</div>
</div>
</div>
</body>
</html>
<footer class="footer-distributed">

    <div class="footer-right">

        <a href="#"><i class="fb"></i><img src="images/fb.png" width="5%"></a>
        <a href="#"><i class="twit"></i><img src="images/twit.png" width="5%" </a>


    </div>

    <div class="footer-left">

        <p class="footer-links">


            <a href="#">Mentions légales</a>
            |
            <a href="contact.php">Contact</a>
            |
            <a href="#">Boutique</a>
            |
            <a href="../../src/Antoine Test/cgu.php">CGU</a>
            |
            <a href="../../src/Antoine Test/cgv.php">CGV</a>
        </p>

        <p>BDE CESI LYON,2017</p>
    </div>

</footer>